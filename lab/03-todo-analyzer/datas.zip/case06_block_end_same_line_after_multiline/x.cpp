int main()
{
    /* TODO: adjust thresholds
       and document rationale */ return 0;
}