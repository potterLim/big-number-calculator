/* TODO: investigate intermittent failure

   repro: run 1000 times

   suspected: race condition */