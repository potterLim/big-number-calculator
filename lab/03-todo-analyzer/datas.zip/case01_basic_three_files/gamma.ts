export function run(): void {
    // TODO: validate args
}