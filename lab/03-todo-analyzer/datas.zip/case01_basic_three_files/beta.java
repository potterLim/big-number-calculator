public final class Beta {
    public static void main(String[] args) {
        // TODO: add input validation
        int x = 10; // TODO: remove magic number
        System.out.println(x);
    }
}