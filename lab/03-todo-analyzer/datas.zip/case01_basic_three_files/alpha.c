int add(int a, int b)
{
    return a + b; // TODO: handle overflow later
}