public final class Mix {
    public static void main(String[] args) {
        // TODO: line one
        /* TODO: block two */ int x = 0;
        // TODO: line three
    }
}