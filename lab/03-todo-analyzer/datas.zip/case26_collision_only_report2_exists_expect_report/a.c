// TODO: should create report.txt first
