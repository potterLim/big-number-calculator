public final class A {
    /* TODO: this is unclosed
    public static void main(String[] args) { }
}