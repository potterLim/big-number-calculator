int main()
{
    int x = 0; // TODO: first // TODO:second (not exact)
    // TODO: third
    return x;
}