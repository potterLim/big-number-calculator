int main()
{
    /* TODO: refactor parsing
       - extract function
       - reduce branching
    */
    return 0;
}